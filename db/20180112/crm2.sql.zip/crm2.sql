-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Počítač: localhost
-- Vytvořeno: Pát 12. led 2018, 11:04
-- Verze serveru: 5.7.20-0ubuntu0.16.04.1-log
-- Verze PHP: 7.1.12-3+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `crm2`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `document`
--

DROP TABLE IF EXISTS `document`;
CREATE TABLE `document` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Vypisuji data pro tabulku `document`
--

INSERT INTO `document` (`id`, `name`, `url`) VALUES
(1, 'První stránka', 'prvni');

-- --------------------------------------------------------

--
-- Struktura tabulky `document_type`
--

DROP TABLE IF EXISTS `document_type`;
CREATE TABLE `document_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sid` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `widget`
--

DROP TABLE IF EXISTS `widget`;
CREATE TABLE `widget` (
  `id` int(11) NOT NULL,
  `document_id` int(11) DEFAULT NULL,
  `tag` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `region` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `sort` int(11) NOT NULL,
  `html` longtext COLLATE utf8_unicode_ci NOT NULL,
  `service` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parameters` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:json_array)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Vypisuji data pro tabulku `widget`
--

INSERT INTO `widget` (`id`, `document_id`, `tag`, `region`, `sort`, `html`, `service`, `parameters`) VALUES
(1, 1, 'div', 'content', 2, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-12","class_sm":null,"class_xs":null,"class_lg":null,"html":"<p><strong>Odstavec<\\/strong><\\/p>\\r\\n<div id=\\"s3gt_translate_tooltip_mini\\" class=\\"s3gt_translate_tooltip_mini_box\\" style=\\"background: initial !important; border: initial !important; border-radius: initial !important; border-spacing: initial !important; border-collapse: initial !important; direction: ltr !important; flex-direction: initial !important; font-weight: initial !important; height: initial !important; letter-spacing: initial !important; min-width: initial !important; max-width: initial !important; min-height: initial !important; max-height: initial !important; margin: auto !important; outline: initial !important; padding: initial !important; position: absolute; table-layout: initial !important; text-align: initial !important; text-shadow: initial !important; width: initial !important; word-break: initial !important; word-spacing: initial !important; overflow-wrap: initial !important; box-sizing: initial !important; display: initial !important; color: inherit !important; font-size: 13px !important; font-family: X-LocaleSpecific, sans-serif, Tahoma, Helvetica !important; line-height: 13px !important; vertical-align: top !important; white-space: inherit !important; left: 112px; top: 35px; opacity: 0.55;\\">\\r\\n<div id=\\"s3gt_translate_tooltip_mini_logo\\" class=\\"s3gt_translate_tooltip_mini\\" title=\\"Translate selected text\\">&nbsp;<\\/div>\\r\\n<div id=\\"s3gt_translate_tooltip_mini_sound\\" class=\\"s3gt_translate_tooltip_mini\\" title=\\"Play\\">&nbsp;<\\/div>\\r\\n<div id=\\"s3gt_translate_tooltip_mini_copy\\" class=\\"s3gt_translate_tooltip_mini\\" title=\\"Copy text to Clipboard\\">&nbsp;<\\/div>\\r\\n<\\/div>"}'),
(2, 1, 'div', 'content', 7, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-12","class_sm":"","class_xs":"","class_lg":"","html":"<p>Odstavec<\\/p>"}'),
(3, 1, 'div', 'content', 9, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-12","class_sm":"","class_xs":"","class_lg":"","html":"<p>Odstavec<\\/p>"}'),
(4, 1, 'div', 'content', 5, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-12","class_sm":null,"class_xs":null,"class_lg":null,"html":"<p>Odstavec Vlo\\u017een&yacute; jako posledn&iacute;, ale je druh&yacute;<\\/p>"}'),
(5, NULL, 'div', 'foot', 1, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-12","class_sm":"","class_xs":"","class_lg":"","html":"<p>Odstavec<\\/p>"}'),
(6, NULL, 'div', 'head', 1, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-12","class_sm":"","class_xs":"","class_lg":"","html":"<p>Odstavec<\\/p>"}'),
(7, NULL, 'div', 'foot', 6, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-12","class_sm":"","class_xs":"","class_lg":"","html":"<p>Odstavec<\\/p>"}'),
(8, 1, 'div', 'content', 7, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-12","class_sm":"","class_xs":"","class_lg":"","html":"<p>Editor<\\/p>"}'),
(9, 1, 'div', 'content', 1, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-12","class_sm":"","class_xs":"","class_lg":"","html":"<p>Editor<\\/p>"}'),
(10, 1, 'div', 'content', 5, 'RRR', 'cms.widget.news', '{"class_md":"col-md-12","class_sm":"","class_xs":"","class_lg":"","title":"N\\u00e1zev aktuality","annotation":"Kr\\u00e1tk\\u00fd popis aktuality","text":"<p>Text aktuality<\\/p>"}'),
(11, NULL, 'div', 'foot', 8, 'RRR', 'cms.widget.news', '{"class_md":"col-md-12","class_sm":null,"class_xs":null,"class_lg":null,"title":"M\\u00e1me nov\\u00e9 auto AAA","annotation":"Kr\\u00e1tk\\u00fd popis aktuality","text":"<p>Toto je del&scaron;&iacute; text aktuality asdasdf asdfasdf asdfasdfa asdfasdf sdfasdfasdf asdf asdfasdf asdfasdfasdf asdfasdf asdfasdf<\\/p>\\r\\n<p>asdfasd<\\/p>\\r\\n<p>asdfasd<\\/p>\\r\\n<p>asdfasdf<\\/p>"}'),
(12, NULL, 'div', 'head', 7, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-12","class_sm":"","class_xs":"","class_lg":"","html":"<p>Editor<\\/p>"}'),
(13, NULL, 'div', 'foot', 1, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-4","class_sm":null,"class_xs":null,"class_lg":null,"html":"<p>AAA<\\/p>"}'),
(14, NULL, 'div', 'foot', 14, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-12","class_sm":"","class_xs":"","class_lg":"","html":"<p>Editor<\\/p>"}'),
(15, 1, 'div', 'content', 6, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-12","class_sm":"","class_xs":"","class_lg":"","html":"<p>Editor<\\/p>"}'),
(16, 1, 'div', 'content', 16, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-12","class_sm":"","class_xs":"","class_lg":"","html":"<p>Editor<\\/p>"}'),
(17, NULL, 'div', 'foot', 15, 'RRR', 'cms.widget.editor', '{"class_md":"col-md-8","class_sm":null,"class_xs":null,"class_lg":null,"html":"<p>Editor<\\/p>"}'),
(18, NULL, 'div', 'foot', 15, 'RRR', 'cms.widget.news', '{"class_md":"col-md-12","class_sm":null,"class_xs":null,"class_lg":null,"title":"N\\u00e1zev aktuality","annotation":"Kr\\u00e1tk\\u00fd popis aktuality. Toto je kr\\u00e1tk\\u00fd popis","text":"<p>Text aktuality<\\/p>"}');

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `document`
--
ALTER TABLE `document`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_D8698A76F47645AE` (`url`);

--
-- Klíče pro tabulku `document_type`
--
ALTER TABLE `document_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_2B6ADBBA57167AB4` (`sid`);

--
-- Klíče pro tabulku `widget`
--
ALTER TABLE `widget`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_85F91ED0C33F7837` (`document_id`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `document`
--
ALTER TABLE `document`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pro tabulku `document_type`
--
ALTER TABLE `document_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pro tabulku `widget`
--
ALTER TABLE `widget`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- Omezení pro exportované tabulky
--

--
-- Omezení pro tabulku `widget`
--
ALTER TABLE `widget`
  ADD CONSTRAINT `FK_85F91ED0C33F7837` FOREIGN KEY (`document_id`) REFERENCES `document` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
